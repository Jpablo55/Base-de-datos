const {MongoClient, ObjectId}= require('mongodb');
const express = require('express')
const uri = 'mongodb+srv://jpjimenez:0123456789@xperience.zqevmru.mongodb.net/';

const client = new MongoClient(uri);

const app = express();

async function getData () {
    await client.connect();
    const db =  await client.db('XPerience')
    const love = db.collection('love')
    console.log(await love.find().toArray())
};

//CRUD

app.get('/data', async (request, response) => {
    response.json( await getData())
})

app.post('/data',async (request, response)=>{
    await client.connect();
    const data = request.body
    const db =  await client.db('XPerience')
    const love = db.collection('love')
    await love.insertOne(data)
    response.json('Creado exitosamente').status(200)
})



   
app.listen(3000, (error) => {
    if(error) throw error;

    console.log('Corriendo en el puerto 3000')
})


