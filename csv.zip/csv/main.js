import mysql from 'mysql2';
import fs from 'fs';
import csv from 'csv-parser';
import csvParser from 'csv-parser';
const conection = mysql.createConnection(
    {
        host : 'localhost',
        user : 'root',
        password : '',
        database : 'crudstore'
    }
);

conection.connect(error => {
    if(error) throw error;

    console.log('Successfull conection')
});

fs.createReadStream('users.csv')
    .pipe(csv())
    .on('data', (row)=>{
        console.log(row)

        conection.query("INSERT INTO users (id,name,email,address) VALUES (?,?,?,?)", [row.id, row.name, row.email, row.address], (error,result) =>{
            if(error) throw error;

            console.log(result)
        })
    })

fs.createReadStream('sales.csv')
    .pipe(csv())
    .on('data', (row)=>{
        console.log(row)

        const{ id,user_id,pay_method,total_price} = row;
        conection.query("INSERT INTO sales (id,user_id,pay_method,total_price) VALUES (?,?,?,?)", [id, user_id, pay_method, total_price], (error,result) =>{
            if(error) throw error;

            console.log(result)
        })
    })