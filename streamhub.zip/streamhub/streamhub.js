// Usar base de datos
use streamhub

// Crear colección usuarios
db.createCollection("usuarios")

// Inserción de un usuario
db.usuarios.insertOne({
    nombre: "Laura Gómez",
    email: "laura.gomez@example.com",
    pais: "Colombia",
    generos_preferidos: ["Drama", "Comedia", "Acción"],
    historial_visualizaciones: [
        {
            contenido_id: ObjectId(),
            fecha: ISODate("2025-08-01T20:00:00Z"),
            minutos_vistos: 120
        }
    ]
})

// Inserción de múltiples contenidos
db.contenido.insertMany([
    {
        tipo: "pelicula",
        titulo: "El Viaje Infinito",
        duracion: 150,
        anio: 2023,
        generos: ["Aventura", "Ciencia Ficción"],
        reparto: ["Carlos Pérez", "Ana Torres"]
    },
    {
        tipo: "serie",
        titulo: "Misterios del Pasado",
        anio: 2022,
        generos: ["Drama", "Suspenso"],
        reparto: ["Luis Martínez", "Camila Herrera"],
        temporadas: [
            {
                numero: 1,
                episodios: [
                    { numero: 1, titulo: "La llegada", duracion: 45 },
                    { numero: 2, titulo: "Sombras", duracion: 50 }
                ]
            }
        ]
    }
])



// Películas con más de 2 horas
db.contenido.find({ tipo: "pelicula", duracion: { $gt: 120 } })

// Usuarios que han visto más de 5 contenidos
db.usuarios.find({ "historial_visualizaciones.5": { $exists: true } })

// Contenidos de género Comedia o Drama
db.contenido.find({ generos: { $in: ["Comedia", "Drama"] } })

// Películas cuyo título contenga "Viaje"
db.contenido.find({ titulo: { $regex: /viaje/i } })




// Agregar colección valoraciones
db.createCollection("valoraciones")

// Insertar valoración de ejemplo
db.valoraciones.insertOne({
    contenido_id: ObjectId(),
    calificacion: 4.5
})

// Actualizar calificación de la valoración
db.valoraciones.updateOne(
    { calificacion: 4.5 },
    { $set: { calificacion: 4.8 } }
)

// Eliminar un usuario por email
db.usuarios.deleteOne({ email: "laura.gomez@example.com" })





// Crear índice por título
db.contenido.createIndex({ titulo: 1 })

// Crear índice compuesto por género y año
db.contenido.createIndex({ generos: 1, anio: -1 })

// Ver índices
db.contenido.getIndexes()





// Promedio de calificación por película
db.valoraciones.aggregate([
    { $group: { _id: "$contenido_id", promedio_calificacion: { $avg: "$calificacion" } } },
    { $sort: { promedio_calificacion: -1 } }
])

// Total de contenidos vistos por usuario
db.usuarios.aggregate([
    { $project: { nombre: 1, total_vistos: { $size: "$historial_visualizaciones" } } }
])

// Géneros más populares
db.contenido.aggregate([
    { $unwind: "$generos" },
    { $group: { _id: "$generos", total: { $sum: 1 } } },
    { $sort: { total: -1 } }
])
